const mockChannels = [{
        id: "0nlbop5f1e",
        name: "Channel 1",
        favorite: false,
        messages: [],
        latestMessage: "17:24"
    },
    {
        id: "6xwd0whqpv",
        name: "Channel 2",
        favorite: false,
        messages: [],
        latestMessage: "17:24"
    },
    {
        id: "pc2z0hhkyf",
        name: "Channel 3",
        favorite: false,
        messages: [],
        latestMessage: "17:24"
    },
    {
        id: "achndt7tst",
        name: "Channel 4",
        favorite: false,
        messages: [],
        latestMessage: "17:24"
    }
];