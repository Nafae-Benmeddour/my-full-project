const mockMessages = [
    {
        createdBy: "Salim Def",
        createdOn: new Date('December 08, 2018 17:24:00'),
        channel: "0nlbop5f1e",
        own: false,
        text: 'What\'s up?',
    },
    {
        createdBy: "Karima Den",
        createdOn: new Date('December 08, 2018 17:24:00'),
        channel: "0nlbop5f1e",
        own: false,
        text: 'The new chatter app looks lit!',
    },
    {
        createdBy: "Sabrina Ada",
        createdOn: new Date('December 08, 2018 17:24:00'),
        channel: "0nlbop5f1e",
        own: false,
        text: 'Learning js is so much fun. What do you think about it?',
    },
    {
        createdBy: "Yahia Sma",
        createdOn: new Date('December 08, 2018 17:24:00'),
        own: false,
        channel: "achndt7tst",
        text: 'I wanna go to Australia!',
    },
    {
        createdBy: "Adel Fra",
        createdOn: new Date('December 08, 2018 17:24:00'),
        channel: "achndt7tst",
        own: false,
        text: 'Me too',
    }
]