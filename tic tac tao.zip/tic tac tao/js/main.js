
var auto_play = true
var auto_play_kind = 0
var two_play = false
var endgame = false
var player1 = []
var player2 = []
var activePlaye = 1
var auto_play_first = false
var co = 0
var score_p1 = 0;
var score_p2 = 0;

function Playgame(id) {
    let choisebtn = document.getElementById(id)
    let chowchange = document.getElementById("showChange")
    console.log("the id of btn : " + id)
    if (!endgame) {
        if (auto_play) {
            if (activePlaye == 1) {
                choisebtn.innerHTML = '<i class="fa-solid fa-xmark"></i> '
                choisebtn.style.pointerEvents = "none"
                player1.push(id)
                activePlaye = 2
                co++


                if (co > 2) {
                    if (checkwener(player1)) {
                        // end the game and play2 is the winner

                        score_p1++;
                        document.getElementById("ScoreP1").innerHTML = " Player X : " + score_p1
                        endgame = true
                        setTimeout(function () {
                            document.getElementById("mainPage").style.display = "none";
                            document.getElementById("winner").style.display = "block";
                            document.getElementById("winnerName").innerHTML = "player X win the game!";
                        }, 1500)
                    } else if (checkwener(player2)) {
                        // end game and play2 is the winner
                        setTimeout(function () {
                            document.getElementById("mainPage").style.display = "none";
                            document.getElementById("winner").style.display = "block";
                            document.getElementById("winnerName").innerHTML = "player O win the game!";
                        }, 1500)
                        score_p2++;
                        document.getElementById("ScoreP2").innerHTML = " Player O : " + score_p2
                        endgame = true
                    } else if (player2.length + player1.length == 9) {
                        // end game for draw
                        setTimeout(function () {
                            document.getElementById("mainPage").style.display = "none";
                            document.getElementById("winner").style.display = "block";
                            document.getElementById("winnerName").innerHTML = "match draw!";
                        }, 1500)
                        endgame = true
                    }
                    else {
                        if (!auto_play_first) {
                            chowchange.style.right = "0px"
                            setTimeout(function () {
                                if (auto_play_kind == 0) autoplay_easy()
                                else if (auto_play_kind == 1) auto_play_Medium()
                            }, 1000)
                        }
                        else { chowchange.style.right = "0px" }
                    }
                }
                else {
                    if (!auto_play_first) {
                        chowchange.style.right = "0px"
                        setTimeout(function () {
                            autoplay_easy()
                        }, 1000)
                    }
                    else { chowchange.style.right = "0px" }
                }
            }
            else {
                choisebtn.innerHTML = '<i class="fa-solid fa-circle-notch"></i>'
                player2.push(id)
                choisebtn.style.pointerEvents = "none"
                activePlaye = 1
                co++
                chowchange.style.right = "170px"
                setTimeout(function () { }, 1000)
                if (co > 3) {
                    if (checkwener(player1)) {
                        setTimeout(function () {
                            document.getElementById("mainPage").style.display = "none";
                            document.getElementById("winner").style.display = "block";
                            document.getElementById("winnerName").innerHTML = "player X win the game!";
                        }, 1500)
                        score_p1++;
                        document.getElementById("ScoreP1").innerHTML = " Player X : " + score_p1
                        endgame = true
                    }
                    else if (checkwener(player2)) {
                        setTimeout(function () {
                            document.getElementById("mainPage").style.display = "none";
                            document.getElementById("winner").style.display = "block";
                            document.getElementById("winnerName").innerHTML = "player O win the game!";
                        }, 1500)
                        score_p2++;
                        document.getElementById("ScoreP2").innerHTML = " Player O : " + score_p2
                        endgame = true
                    }
                    else if (player2.length + player1.length == 9) {
                        setTimeout(function () {
                            document.getElementById("mainPage").style.display = "none";
                            document.getElementById("winner").style.display = "block";
                            document.getElementById("winnerName").innerHTML = "match draw!";
                        }, 1500)
                        endgame = true
                    }
                    else {
                        if (auto_play_first) {
                            chowchange.style.right = "170px"
                            setTimeout(function () {
                                if (auto_play_kind == 0) autoplay_easy()
                                else if (auto_play_kind == 1) auto_play_Medium()
                            }, 1000)
                        }
                        else { chowchange.style.right = "170px" }
                    }
                }
                else {
                    if (auto_play_first) {
                        chowchange.style.right = "170px"
                        setTimeout(() => {
                            autoplay_easy()
                        }, 1000);
                    }
                    else {
                        chowchange.style.right = "170px"
                    }
                }
            }
        } else if (two_play) {
            if (activePlaye == 1) {
                choisebtn.innerHTML = '<i class="fa-solid fa-xmark"></i>'
                choisebtn.style.pointerEvents = "none"

                player1.push(id)
                activePlaye = 2
                co++
            }
            else {

                choisebtn.innerHTML = '<i class="fa-solid fa-circle-notch"></i>'
                player2.push(id)
                choisebtn.style.pointerEvents = "none"
                activePlaye = 1
                co++
            }
            if (co > 4) {
                if (checkwener(player1)) { //p1 
                    setTimeout(function () {
                        document.getElementById("mainPage").style.display = "none";
                        document.getElementById("winner").style.display = "block";
                        document.getElementById("winnerName").innerHTML = "player X win the game!";
                    }, 1500)
                    score_p1++;
                    document.getElementById("ScoreP1").innerHTML = " Player X : " + score_p1
                    endgame = true
                }
                else if (checkwener(player2)) {//p2
                    setTimeout(function () {
                        document.getElementById("mainPage").style.display = "none";
                        document.getElementById("winner").style.display = "block";
                        document.getElementById("winnerName").innerHTML = "player O win the game!";
                    }, 1500)
                    score_p2++;
                    document.getElementById("ScoreP2").innerHTML = " Player O : " + score_p2
                    endgame = true
                }
                else if (player2.length + player1.length == 9) {
                    setTimeout(function () {
                        document.getElementById("mainPage").style.display = "none";
                        document.getElementById("winner").style.display = "block";
                        document.getElementById("winnerName").innerHTML = "match draw!";
                    }, 1500)
                    endgame = true
                }
            }
            if (activePlaye == 1) {
                chowchange.style.right = "170px"
            }
            else {
                chowchange.style.right = "0px"
            }
        }
    }
}
function DrawLine(className) {
    document.getElementById('gameBoard').className = className
}

function Restscore() {
    score_p1 = 0
    score_p2 = 0
    document.getElementById("ScoreP2").innerHTML = "O score : " + score_p2
    document.getElementById("ScoreP1").innerHTML = "X score : " + score_p1
}
function playAgain() {
    document.getElementById("mainPage").style.display = "block"
    document.getElementById("winner").style.display = "none"
    replay(false, auto_play_first)
}

function replay(score, startgame) {
    let btn_l = []
    btn_l.push(document.getElementById('1'))
    btn_l.push(document.getElementById('2'))
    btn_l.push(document.getElementById('3'))
    btn_l.push(document.getElementById('4'))
    btn_l.push(document.getElementById('5'))
    btn_l.push(document.getElementById('6'))
    btn_l.push(document.getElementById('7'))
    btn_l.push(document.getElementById('8'))
    btn_l.push(document.getElementById('9'))
    for (i in btn_l) {
        btn_l[i].innerHTML = ""
        btn_l[i].style.pointerEvents = "auto"
        activePlaye = 1
    }
    player1 = []
    player2 = []
    endgame = false; co = 0
    let chowchange = document.getElementById("showChange")
    DrawLine("hideLine")
    if (!auto_play) { chowchange.style.right = "170px" }
    else if (startgame && auto_play_first) {
        Bot_First(true)
    }

    if (score) {
        Restscore()
    }
}


function restartGame() {
    document.getElementById("startingPage").style.display = "block"
    document.getElementById("mainPage").style.display = "none"
    replay(true, false)
}

function Bot_First(bot) {
    if (bot) {
        auto_play_first = true
        let chowchange = document.getElementById("showChange")
        chowchange.style.right = "0px"
        setTimeout(function () { }, 1000)
        autoplay_easy()
    }
    else {
        auto_play_first = false
    }
    document.getElementById("startingPage").style.display = "none"
    document.getElementById("mainPage").style.display = "block"
}

function select_kindPlay() {
    var selectV = Number(document.getElementById("select").value)
    if (selectV == 3) {
        auto_play = false
        auto_play_kind = -1
        two_play = true
        replay(true, false)
        document.getElementById('btn1').style.display = "none"
        document.getElementById('btn2').style.display = "none"
        document.getElementById('h4').style.display = "none"
        document.getElementById('btn3').style.display = "block"
        document.getElementById('startingPage').style.height = "290px"
    }
    else {
        auto_play = true
        auto_play_kind = selectV
        two_play = false
        replay(true, false)
        document.getElementById('btn1').style.display = "block"
        document.getElementById('btn2').style.display = "block"
        document.getElementById('h4').style.display = "block"
        document.getElementById('btn3').style.display = "none"
        document.getElementById('startingPage').style.height = "340px"
    }

}


function checkwener(player) {

    if (player.includes(1) && player.includes(2) && player.includes(3)) {
        DrawLine("firstRow")
        return true
    }
    else if (player.includes(4) && player.includes(5) && player.includes(6)) {
        DrawLine("secondRow")
        return true
    }
    else if (player.includes(7) && player.includes(8) && player.includes(9)) {
        DrawLine("lastRow")
        return true
    }
    else if (player.includes(1) && player.includes(4) && player.includes(7)) {
        DrawLine("firstLine")
        return true
    }
    else if (player.includes(5) && player.includes(2) && player.includes(8)) {
        DrawLine("secondLine")
        return true
    }
    else if (player.includes(6) && player.includes(9) && player.includes(3)) {
        DrawLine("lastLine")
        return true
    }
    else if (player.includes(1) && player.includes(5) && player.includes(9)) {
        DrawLine("firstLRow")
        return true
    }
    else if (player.includes(3) && player.includes(5) && player.includes(7)) {
        DrawLine("secondLRow")
        return true
    }
    else {
        return false
    }
}
function autoplay_easy() {
    let empety = []
    for (let i = 1; i <= 9; i++) {
        if (!(player1.includes(i) || player2.includes(i))) {
            empety.push(i)
        }
    }
    let randIndex = Math.floor(Math.random() * empety.length)
    Playgame(empety[randIndex])
}
function auto_play_Medium() {
    let empety = []
    for (let i = 1; i <= 9; i++) {
        if (!(player1.includes(i) || player2.includes(i))) {
            empety.push(i)
        }
    }
    if (auto_play_first) {

        if ((player1.includes(1) && player1.includes(9) && empety.includes(5)) || (player1.includes(6) && player1.includes(4) && empety.includes(5)) || (player1.includes(7) && player1.includes(3) && empety.includes(5)) || (player1.includes(2) && player1.includes(8) && empety.includes(5))) {
            Playgame(5)
        }
        else if ((player1.includes(1) && player1.includes(2) && empety.includes(3)) || (player1.includes(6) && player1.includes(9) && empety.includes(3)) || (player1.includes(7) && player1.includes(5) && empety.includes(3))) {
            Playgame(3)
        }
        else if ((player1.includes(3) && player1.includes(2) && empety.includes(1)) || (player1.includes(4) && player1.includes(7) && empety.includes(1)) || (player1.includes(9) && player1.includes(5) && empety.includes(1))) {
            Playgame(1)
        }
        else if ((player1.includes(1) && player1.includes(4) && empety.includes(7)) || (player1.includes(8) && player1.includes(9) && empety.includes(7)) || (player1.includes(3) && player1.includes(5) && empety.includes(7))) {
            Playgame(7)
        }
        else if ((player1.includes(3) && player1.includes(6) && empety.includes(9)) || (player1.includes(8) && player1.includes(7) && empety.includes(9)) || (player1.includes(1) && player1.includes(5) && empety.includes(9))) {
            Playgame(9)
        }
        else if ((player1.includes(1) && player1.includes(3) && empety.includes(2)) || (player1.includes(8) && player1.includes(5) && empety.includes(2))) {
            Playgame(2)
        }
        else if ((player1.includes(1) && player1.includes(7) && empety.includes(4)) || (player1.includes(6) && player1.includes(5) && empety.includes(4))) {
            Playgame(4)
        }
        else if ((player1.includes(3) && player1.includes(9) && empety.includes(6)) || (player1.includes(4) && player1.includes(5) && empety.includes(6))) {
            Playgame(6)
        }
        else if ((player1.includes(7) && player1.includes(9) && empety.includes(8)) || (player1.includes(2) && player1.includes(5) && empety.includes(8))) {
            Playgame(8)
        }
        else if ((player2.includes(1) && player2.includes(9) && empety.includes(5)) || (player2.includes(6) && player2.includes(4) && empety.includes(5)) || (player2.includes(7) && player2.includes(3) && empety.includes(5)) || (player2.includes(2) && player2.includes(8) && empety.includes(5))) {
            Playgame(5)
        }
        else if ((player2.includes(1) && player2.includes(2) && empety.includes(3)) || (player2.includes(6) && player2.includes(9) && empety.includes(3)) || (player2.includes(7) && player2.includes(5) && empety.includes(3))) {
            Playgame(3)
        }
        else if ((player2.includes(3) && player2.includes(2) && empety.includes(3)) || (player2.includes(4) && player2.includes(7) && empety.includes(1)) || (player2.includes(9) && player2.includes(5) && empety.includes(1))) {
            Playgame(1)
        }
        else if ((player2.includes(1) && player2.includes(4) && empety.includes(7)) || (player2.includes(8) && player2.includes(9) && empety.includes(7)) || (player2.includes(3) && player2.includes(5) && empety.includes(7))) {
            Playgame(7)
        }
        else if ((player2.includes(3) && player2.includes(6) && empety.includes(9)) || (player2.includes(8) && player2.includes(7) && empety.includes(9)) || (player2.includes(1) && player2.includes(5) && empety.includes(9))) {
            Playgame(9)
        }
        else if ((player2.includes(1) && player2.includes(3) && empety.includes(2)) || (player2.includes(8) && player2.includes(5) && empety.includes(2))) {
            Playgame(2)
        }
        else if ((player2.includes(1) && player2.includes(7) && empety.includes(4)) || (player2.includes(6) && player2.includes(5) && empety.includes(4))) {
            Playgame(4)
        }
        else if ((player2.includes(3) && player2.includes(9) && empety.includes(6)) || (player2.includes(4) && player2.includes(5) && empety.includes(6))) {
            Playgame(6)
        }
        else if ((player2.includes(7) && player2.includes(9) && empety.includes(8)) || (player2.includes(2) && player2.includes(5) && empety.includes(8))) {
            Playgame(8)
        }
        else {
            autoplay_easy()
        }
    }
    else {
        if ((player2.includes(1) && player2.includes(9) && empety.includes(5)) || (player2.includes(6) && player2.includes(4) && empety.includes(5)) || (player2.includes(7) && player2.includes(3) && empety.includes(5)) || (player2.includes(2) && player2.includes(8) && empety.includes(5))) {
            Playgame(5)
        }
        else if ((player2.includes(1) && player2.includes(2) && empety.includes(3)) || (player2.includes(6) && player2.includes(9) && empety.includes(3)) || (player2.includes(7) && player2.includes(5) && empety.includes(3))) {
            Playgame(3)
        }
        else if ((player2.includes(3) && player2.includes(2) && empety.includes(1)) || (player2.includes(4) && player2.includes(7) && empety.includes(1)) || (player2.includes(9) && player2.includes(5) && empety.includes(1))) {
            Playgame(1)
        }
        else if ((player2.includes(1) && player2.includes(4) && empety.includes(7)) || (player2.includes(8) && player2.includes(9) && empety.includes(7)) || (player2.includes(3) && player2.includes(5) && empety.includes(7))) {
            Playgame(7)
        }
        else if ((player1.includes(3) && player2.includes(6) && empety.includes(9)) || (player2.includes(8) && player2.includes(7) && empety.includes(9)) || (player2.includes(1) && player2.includes(5) && empety.includes(9))) {
            Playgame(9)
        }
        else if ((player2.includes(1) && player2.includes(3) && empety.includes(2)) || (player2.includes(8) && player2.includes(5) && empety.includes(2))) {
            Playgame(2)
        }
        else if ((player2.includes(1) && player2.includes(7) && empety.includes(4)) || (player2.includes(6) && player2.includes(5) && empety.includes(4))) {
            Playgame(4)
        }
        else if ((player2.includes(3) && player2.includes(9) && empety.includes(6)) || (player2.includes(4) && player2.includes(5) && empety.includes(6))) {
            Playgame(6)
        }
        else if ((player2.includes(7) && player2.includes(9) && empety.includes(8)) || (player2.includes(2) && player2.includes(5) && empety.includes(8))) {
            Playgame(8)
        }
        else if ((player1.includes(1) && player1.includes(9) && empety.includes(5)) || (player1.includes(6) && player1.includes(4) && empety.includes(5)) || (player1.includes(7) && player1.includes(3) && empety.includes(5)) || (player1.includes(2) && player1.includes(8) && empety.includes(5))) {
            Playgame(5)
        }
        else if ((player1.includes(1) && player1.includes(2) && empety.includes(3)) || (player1.includes(6) && player1.includes(9) && empety.includes(3)) || (player1.includes(7) && player1.includes(5) && empety.includes(3))) {
            Playgame(3)
        }
        else if ((player1.includes(3) && player1.includes(2) && empety.includes(3)) || (player1.includes(4) && player1.includes(7) && empety.includes(1)) || (player1.includes(9) && player1.includes(5) && empety.includes(1))) {
            Playgame(1)
        }
        else if ((player1.includes(1) && player1.includes(4) && empety.includes(7)) || (player1.includes(8) && player1.includes(9) && empety.includes(7)) || (player1.includes(3) && player1.includes(5) && empety.includes(7))) {
            Playgame(7)
        }
        else if ((player1.includes(3) && player1.includes(6) && empety.includes(9)) || (player1.includes(8) && player1.includes(7) && empety.includes(9)) || (player1.includes(1) && player1.includes(5) && empety.includes(9))) {
            Playgame(9)
        }
        else if ((player1.includes(1) && player1.includes(3) && empety.includes(2)) || (player1.includes(8) && player1.includes(5) && empety.includes(2))) {
            Playgame(2)
        }
        else if ((player1.includes(1) && player1.includes(7) && empety.includes(4)) || (player1.includes(6) && player1.includes(5) && empety.includes(4))) {
            Playgame(4)
        }
        else if ((player1.includes(3) && player1.includes(9) && empety.includes(6)) || (player1.includes(4) && player1.includes(5) && empety.includes(6))) {
            Playgame(6)
        }
        else if ((player1.includes(7) && player1.includes(9) && empety.includes(8)) || (player1.includes(2) && player1.includes(5) && empety.includes(8))) {
            Playgame(8)
        }
        else {
            autoplay_easy()
        }
    }

}
